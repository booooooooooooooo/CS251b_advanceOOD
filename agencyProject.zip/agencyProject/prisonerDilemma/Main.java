import agency.*;
public class Main{
  public static void main(String args[]){
    Judge jg = new Judge();
    jg.start();
  }
}
