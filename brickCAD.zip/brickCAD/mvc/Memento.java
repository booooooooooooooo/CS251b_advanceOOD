package mvc;


public interface Memento{

}
