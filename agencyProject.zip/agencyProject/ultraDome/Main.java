import java.util.*;
public class Main{
  public static void main(String args[]){

    UltraDome ud = new UltraDome();
    ud.start();




    // Weapon weapon = Weapon.Iron;
    // Skin skin = Skin.IronSkin;
    // System.out.println(skin.getTargetWeapon() == weapon);
    // System.out.println(weapon.getHarm());
    // System.out.printf("%s\n",skin.getTargetWeapon().toString());

    // Shield oldShield = new Shield(skin, null);
    // Shield shield = new Shield(skin, oldShield);
    // double harm = oldShield.getHarmAfterDefense(weapon);
    // System.out.println(harm);
  }
}
