package agency;

public interface Message{

}
