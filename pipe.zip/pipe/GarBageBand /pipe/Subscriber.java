package pipe;

public interface Subscriber<T>{
  public void update();
}
